-- XAN HUB | MM2 GUI demo
-- Interface-only demo. Toggles change their visual state only.
-- No role reading, god mode, forced flinging, or player manipulation.

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local player = Players.LocalPlayer

local guiParent = game:GetService("CoreGui")
local gui = Instance.new("ScreenGui")
gui.Name = "XAN_HUB"
gui.ResetOnSpawn = false
gui.Parent = guiParent

local purple = Color3.fromRGB(145, 75, 255)
local dark = Color3.fromRGB(19, 15, 28)
local panel = Color3.fromRGB(35, 27, 48)

local main = Instance.new("Frame")
main.Name = "Main"
main.Size = UDim2.fromOffset(470, 340)
main.Position = UDim2.new(0.5, -235, 0.5, -170)
main.BackgroundColor3 = dark
main.BorderSizePixel = 0
main.Parent = gui
Instance.new("UICorner", main).CornerRadius = UDim.new(0, 12)

local outline = Instance.new("UIStroke")
outline.Color = purple
outline.Thickness = 2
outline.Parent = main

local header = Instance.new("Frame")
header.Size = UDim2.new(1, 0, 0, 45)
header.BackgroundColor3 = panel
header.BorderSizePixel = 0
header.Parent = main
Instance.new("UICorner", header).CornerRadius = UDim.new(0, 12)

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -115, 1, 0)
title.Position = UDim2.fromOffset(13, 0)
title.BackgroundTransparency = 1
title.Text = "XAN HUB  |  MM2"
title.TextColor3 = Color3.new(1, 1, 1)
title.TextXAlignment = Enum.TextXAlignment.Left
title.Font = Enum.Font.GothamBold
title.TextSize = 17
title.Parent = header

local function headerButton(text, x)
    local button = Instance.new("TextButton")
    button.Size = UDim2.fromOffset(30, 28)
    button.Position = UDim2.new(1, x, 0, 8)
    button.BackgroundColor3 = purple
    button.TextColor3 = Color3.new(1, 1, 1)
    button.Font = Enum.Font.GothamBold
    button.Text = text
    button.Parent = header
    Instance.new("UICorner", button).CornerRadius = UDim.new(0, 7)
    return button
end

local minimize = headerButton("–", -74)
local close = headerButton("×", -38)

local body = Instance.new("Frame")
body.Position = UDim2.fromOffset(10, 55)
body.Size = UDim2.new(1, -20, 1, -65)
body.BackgroundTransparency = 1
body.Parent = main

local sidebar = Instance.new("Frame")
sidebar.Size = UDim2.new(0, 115, 1, 0)
sidebar.BackgroundTransparency = 1
sidebar.Parent = body

local content = Instance.new("Frame")
content.Position = UDim2.fromOffset(125, 0)
content.Size = UDim2.new(1, -125, 1, 0)
content.BackgroundColor3 = panel
content.BorderSizePixel = 0
content.Parent = body
Instance.new("UICorner", content).CornerRadius = UDim.new(0, 10)

-- Drag the window from the header.
local dragging = false
local dragInput, dragStart, startPosition

header.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPosition = main.Position
        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false
            end
        end)
    end
end)

header.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement
        or input.UserInputType == Enum.UserInputType.Touch then
        dragInput = input
    end
end)

UserInputService.InputChanged:Connect(function(input)
    if dragging and input == dragInput then
        local delta = input.Position - dragStart
        main.Position = UDim2.new(
            startPosition.X.Scale, startPosition.X.Offset + delta.X,
            startPosition.Y.Scale, startPosition.Y.Offset + delta.Y
        )
    end
end)

local pages = {}
local selectedPage

local function createPage(name)
    local page = Instance.new("ScrollingFrame")
    page.Name = name
    page.Size = UDim2.new(1, -12, 1, -12)
    page.Position = UDim2.fromOffset(6, 6)
    page.BackgroundTransparency = 1
    page.BorderSizePixel = 0
    page.ScrollBarThickness = 3
    page.CanvasSize = UDim2.new(0, 0, 0, 0)
    page.Visible = false
    page.Parent = content

    local layout = Instance.new("UIListLayout")
    layout.Padding = UDim.new(0, 8)
    layout.Parent = page
    layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        page.CanvasSize = UDim2.new(0, 0, 0, layout.AbsoluteContentSize.Y + 10)
    end)

    pages[name] = page
    return page
end

local function showPage(name)
    for pageName, page in pairs(pages) do
        page.Visible = pageName == name
    end
    selectedPage = name
end

local function addToggle(page, label)
    local enabled = false
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(1, -5, 0, 38)
    button.BackgroundColor3 = Color3.fromRGB(65, 45, 90)
    button.TextColor3 = Color3.new(1, 1, 1)
    button.Font = Enum.Font.GothamSemibold
    button.TextSize = 13
    button.Text = label .. "  [OFF]"
    button.Parent = page
    Instance.new("UICorner", button).CornerRadius = UDim.new(0, 8)

    button.MouseButton1Click:Connect(function()
        enabled = not enabled
        button.Text = label .. (enabled and "  [ON]" or "  [OFF]")
        button.BackgroundColor3 = enabled
            and Color3.fromRGB(70, 135, 100)
            or Color3.fromRGB(65, 45, 90)
    end)
end

local tabNames = { "Main", "Combat", "ESP", "Movement", "Settings" }

for index, name in ipairs(tabNames) do
    local page = createPage(name)
    local tab = Instance.new("TextButton")
    tab.Size = UDim2.new(1, 0, 0, 36)
    tab.Position = UDim2.fromOffset(0, (index - 1) * 43)
    tab.BackgroundColor3 = Color3.fromRGB(55, 38, 75)
    tab.Text = name
    tab.TextColor3 = Color3.new(1, 1, 1)
    tab.Font = Enum.Font.GothamBold
    tab.TextSize = 13
    tab.Parent = sidebar
    Instance.new("UICorner", tab).CornerRadius = UDim.new(0, 8)

    tab.MouseButton1Click:Connect(function()
        showPage(name)
    end)
end

addToggle(pages.Main, "Murderer Revealer (demo)")
addToggle(pages.Main, "Sheriff Revealer (demo)")
addToggle(pages.Combat, "Fling (visual demo)")
addToggle(pages.Combat, "Headsit (visual demo)")
addToggle(pages.Combat, "God Mode (visual demo)")
addToggle(pages.ESP, "Player ESP (demo)")
addToggle(pages.ESP, "Name ESP (demo)")
addToggle(pages.Movement, "Speed Display (demo)")
addToggle(pages.Movement, "Jump Display (demo)")
addToggle(pages.Settings, "GUI Effects")

showPage("Main")

local expandedSize = main.Size
local minimized = false
minimize.MouseButton1Click:Connect(function()
    minimized = not minimized
    body.Visible = not minimized
    main.Size = minimized and UDim2.fromOffset(470, 45) or expandedSize
end)

close.MouseButton1Click:Connect(function()
    gui:Destroy()
end)

print("XAN HUB GUI demo loaded.")
